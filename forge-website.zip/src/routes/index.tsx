import { createFileRoute } from "@tanstack/react-router";

import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { HeroVisual } from "@/components/site/HeroVisual";
import { Reveal, SectionLabel, ArrowLink, Counter } from "@/components/site/primitives";

import { DOMAINS, PROJECTS, EVENTS, WORKSHOPS, TEAM, ROBOTICS_WORKSHOP, PRINTING_WORKSHOP, PRINCIPAL, HOD, STAFF } from "@/lib/home-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FORGE — Mechanical Engineering Association" },
      {
        name: "description",
        content:
          "FORGE is a student-run Mechanical Engineering Association: CAD, manufacturing, robotics, automotive and thermal projects, workshops and events.",
      },
      { property: "og:title", content: "FORGE — Mechanical Engineering Association" },
      {
        property: "og:description",
        content:
          "Design. Build. Move. A student association creating engineers through hands-on projects, workshops and real-world innovation.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const renderCards = (
    items: { name: string; title: string; qualification: string; email?: string; img?: string }[],
    baseDelay = 0,
  ) =>
    items.map((f, i) => (
      <Reveal
        as="li"
        key={f.name}
        delay={baseDelay + i * 80}
        className="group border border-border p-5 transition-colors hover:bg-surface"
      >
        <div className="relative flex aspect-[4/5] items-center justify-center overflow-hidden bg-secondary">
          {f.img ? (
            <img
              src={f.img}
              alt={f.name}
              className="h-full w-full object-cover grayscale transition-all duration-500 group-hover:grayscale-0"
              loading="lazy"
            />
          ) : (
            <span className="display-xl text-6xl text-steel/40 transition-colors duration-500 group-hover:text-accent/60">
              {f.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </span>
          )}
          <svg
            viewBox="0 0 100 125"
            className="pointer-events-none absolute inset-0 h-full w-full stroke-foreground/10"
            fill="none"
            aria-hidden
          >
            <circle cx="50" cy="62" r="34" strokeWidth="0.5" />
            <line x1="0" y1="62" x2="100" y2="62" strokeWidth="0.5" />
            <line x1="50" y1="0" x2="50" y2="125" strokeWidth="0.5" />
          </svg>
        </div>
        <h4 className="mt-5 font-display text-lg font-bold uppercase tracking-tight">{f.name}</h4>
        <p className="tech-label mt-1 text-accent">{f.title}</p>
        <p className="tech-label mt-1 text-steel">{f.qualification}</p>
        {f.email ? (
          <a
            href={`mailto:${f.email}`}
            className="tech-label mt-1 block break-all text-steel/70 transition-colors hover:text-accent"
          >
            {f.email}
          </a>
        ) : null}
      </Reveal>
    ));

  return (
    <div id="top" className="min-h-screen">
      <SiteHeader />
      <main>
        {/* HERO */}
        <section className="relative overflow-hidden px-5 pt-32 pb-16 md:px-10 md:pt-40">
          <div className="pointer-events-none absolute inset-0 blueprint-grid opacity-40" aria-hidden />
          <div className="relative mx-auto max-w-[1680px]">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4">
              <span className="tech-label">MEA / 2026</span>
              <span className="tech-label hidden sm:inline">Engineering • Design • Innovation</span>
              <span className="tech-label text-accent">01 / 06</span>
            </div>

            <div className="grid items-center gap-10 pt-10 lg:grid-cols-[1.15fr_1fr] lg:gap-16">
              <Reveal>
                <h1 className="display-xl text-[15vw] leading-[0.85] sm:text-[12vw] lg:text-[8.2vw]">
                  Mechanical
                  <br />
                  Engineering
                  <br />
                  <span className="text-steel">Association</span>
                </h1>
                <p className="mt-8 max-w-md font-mono text-[0.72rem] uppercase tracking-[0.2em] text-accent">
                  Design. Build. Move.
                </p>
                <p className="mt-4 max-w-md text-base leading-relaxed text-steel">
                  Creating engineers through hands-on experience, technical knowledge and
                  real-world innovation.
                </p>
                <div className="mt-10 flex flex-wrap gap-3">
                  <ArrowLink href="#projects" variant="solid">
                    Explore Projects
                  </ArrowLink>
                  <ArrowLink href="#contact" variant="outline">
                    Join the Association
                  </ArrowLink>
                </div>
              </Reveal>

              <Reveal delay={120} className="mx-auto w-full max-w-[560px]">
                <HeroVisual />
              </Reveal>
            </div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="01">Who we are</SectionLabel>
            <div className="mt-10 grid gap-12 lg:grid-cols-[1.2fr_1fr]">
              <Reveal>
                <h2 className="display-xl text-[9vw] sm:text-[6.5vw] lg:text-[4.4vw]">
                  Built by students.
                  <br />
                  <span className="text-steel">Driven by engineering.</span>
                </h2>
              </Reveal>
              <Reveal delay={100} className="lg:pt-4">
                <p className="max-w-xl text-2xl leading-relaxed text-foreground">
                  The Mechanical Engineering Association is a student-driven community of Students Of
                  SreeRama Goverment Polytecnic Collage focused on developing technical skills,
                  encouraging innovation, building practical projects, and connecting students with
                  the world of mechanical engineering.
                </p>
                <div className="mt-10 flex items-end gap-5">
                  <span className="display-xl text-[22vw] text-foreground sm:text-[12vw] lg:text-[8vw]">
                    <Counter to={100} suffix="+" />
                  </span>
                  <span className="tech-label pb-4">Students / Members</span>
                </div>
              </Reveal>
            </div>

            <div className="mt-20 grid border-t border-border sm:grid-cols-3">
              {[
                { n: 20, l: "Projects" },
                { n: 15, l: "Events" },
                { n: 10, l: "Workshops" },
              ].map((s, i) => (
                <Reveal
                  key={s.l}
                  delay={i * 80}
                  className="border-b border-border px-1 py-8 sm:border-b-0 sm:border-r sm:px-8 sm:last:border-r-0 sm:first:pl-0"
                >
                  <p className="display-xl text-5xl md:text-6xl">
                    <Counter to={s.n} suffix="+" />
                  </p>
                  <p className="tech-label mt-3">{s.l}</p>
                </Reveal>
              ))}
            </div>

            {/* ADMINISTRATION */}
            <div className="mt-20 border-t border-border pt-14">
              <SectionLabel index="01-A">Administration</SectionLabel>

              {/* Principal */}
              <h3 className="display-xl mt-6 text-[7vw] sm:text-[5vw] lg:text-[3.2vw]">Principal</h3>
              <ul className="mt-10 grid max-w-sm gap-6">
                {renderCards(PRINCIPAL)}
              </ul>

              {/* Head of Department */}
              <h3 className="display-xl mt-16 border-t border-border pt-14 text-[7vw] sm:text-[5vw] lg:text-[3.2vw]">
                Head of Department
              </h3>
              <ul className="mt-10 grid max-w-sm gap-6">
                {renderCards(HOD)}
              </ul>

              {/* Staff Profile */}
              <h3 className="display-xl mt-16 border-t border-border pt-14 text-[7vw] sm:text-[5vw] lg:text-[3.2vw]">
                Staff Profile
              </h3>
              <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {renderCards(STAFF)}
              </ul>
            </div>
          </div>
        </section>

        {/* DOMAINS */}
        <section className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="02">Disciplines</SectionLabel>
            <h2 className="display-xl mt-8 text-[10vw] sm:text-[7vw] lg:text-[5vw]">
              What we engineer
            </h2>
            <ul className="mt-14 grid border-t border-border md:grid-cols-2 xl:grid-cols-3">
              {DOMAINS.map((d, i) => (
                <Reveal
                  as="li"
                  key={d.n}
                  delay={(i % 3) * 70}
                  className="group relative border-b border-border p-8 transition-colors duration-300 hover:bg-surface md:odd:border-r xl:[&:nth-child(3n)]:border-r-0 xl:border-r"
                >
                  <div className="flex items-start justify-between gap-4">
                    <span className="tech-label transition-colors group-hover:text-accent">
                      {d.n} —
                    </span>
                    <span className="tech-label opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-hover:text-accent">
                      &rarr;
                    </span>
                  </div>
                  <svg
                    viewBox="0 0 120 60"
                    className="mt-6 h-16 w-32 stroke-steel transition-colors duration-300 group-hover:stroke-accent"
                    fill="none"
                    aria-hidden
                  >
                    <circle cx="30" cy="30" r="20" strokeWidth="1" />
                    <circle cx="30" cy="30" r="7" strokeWidth="1" />
                    <line x1="55" y1="30" x2="115" y2="30" strokeWidth="1" strokeDasharray="4 4" />
                    <rect x="72" y="18" width="24" height="24" strokeWidth="1" />
                  </svg>
                  <h3 className="mt-6 font-display text-2xl font-bold uppercase tracking-tight">
                    {d.t}
                  </h3>
                  <p className="mt-3 max-w-sm text-sm leading-relaxed text-steel">{d.d}</p>
                </Reveal>
              ))}
            </ul>
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="03">Selected work</SectionLabel>
            <h2 className="display-xl mt-8 text-[11vw] sm:text-[8vw] lg:text-[6vw]">
              Projects that move.
            </h2>

            <div className="mt-16 grid gap-x-10 gap-y-16 md:grid-cols-2">
              {PROJECTS.map((p, i) => (
                <Reveal as="article" key={p.name} delay={(i % 2) * 90} className="group">
                  <div className="overflow-hidden border border-border bg-surface">
                    <img
                      src={p.img}
                      alt={p.name}
                      width={1200}
                      height={900}
                      loading="lazy"
                      className="aspect-[4/3] w-full object-cover grayscale transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                    />
                  </div>
                  <div className="mt-5 flex items-baseline justify-between gap-4 border-t border-border pt-4">
                    <h3 className="font-display text-2xl font-bold uppercase tracking-tight md:text-3xl">
                      {p.name}
                    </h3>
                    <span className="tech-label shrink-0">
                      {p.cat} / {p.year}
                    </span>
                  </div>
                  <p className="mt-3 max-w-lg text-sm leading-relaxed text-steel">{p.desc}</p>
                  <div className="mt-5 flex flex-wrap items-center gap-2">
                    {p.tags.map((t) => (
                      <span key={t} className="tech-label border border-border px-3 py-1.5">
                        {t}
                      </span>
                    ))}
                  </div>
                  <div className="mt-6">
                    <ArrowLink href="#contact">View Project</ArrowLink>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* EVENTS */}
        <section id="events" className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="04">Calendar</SectionLabel>
            <h2 className="display-xl mt-8 text-[11vw] sm:text-[8vw] lg:text-[6vw]">
              Engineering in action.
            </h2>

            <ul className="mt-14 border-t border-border">
              {EVENTS.map((e, i) => (
                <Reveal
                  as="li"
                  key={e.name}
                  delay={i * 50}
                  className="group grid grid-cols-[auto_minmax(0,1fr)] items-center gap-x-6 gap-y-2 border-b border-border py-7 transition-colors hover:bg-surface md:grid-cols-[120px_minmax(0,1fr)_180px_140px_auto]"
                >
                  <div className="flex items-baseline gap-2">
                    <span className="display-xl text-4xl md:text-5xl">{e.d}</span>
                    <span className="tech-label">{e.m}</span>
                  </div>
                  <h3 className="font-display text-xl font-bold uppercase tracking-tight md:text-2xl">
                    {e.name}
                  </h3>
                  <span className="tech-label col-start-2 md:col-start-auto">{e.loc}</span>
                  <span className="tech-label col-start-2 text-accent md:col-start-auto">
                    {e.cat}
                  </span>
                  <span className="col-start-2 md:col-start-auto md:justify-self-end">
                    <ArrowLink href="#contact">View Event</ArrowLink>
                  </span>
                </Reveal>
              ))}
            </ul>
          </div>
        </section>

        {/* WORKSHOPS */}
        <section className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="05">Skills lab</SectionLabel>
            <h2 className="display-xl mt-8 text-[10vw] sm:text-[7vw] lg:text-[5vw]">
              Learn. Build. Test. Repeat.
            </h2>
            <ul className="mt-14 grid border-t border-l border-border sm:grid-cols-2 lg:grid-cols-3">
              {WORKSHOPS.map((w, i) => (
                <Reveal
                  as="li"
                  key={w}
                  delay={(i % 3) * 60}
                  className="group flex items-center justify-between gap-4 border-r border-b border-border px-6 py-8 transition-colors hover:bg-surface"
                >
                  <div className="min-w-0">
                    <span className="tech-label">{String(i + 1).padStart(2, "0")}</span>
                    <p className="mt-2 truncate font-display text-xl font-bold uppercase tracking-tight">
                      {w}
                    </p>
                  </div>
                  <svg
                    viewBox="0 0 40 40"
                    className="h-10 w-10 shrink-0 stroke-steel transition-colors group-hover:stroke-accent"
                    fill="none"
                    aria-hidden
                  >
                    <circle cx="20" cy="20" r="14" strokeWidth="1" />
                    <circle cx="20" cy="20" r="5" strokeWidth="1" />
                    <line x1="20" y1="0" x2="20" y2="8" strokeWidth="1" />
                    <line x1="20" y1="32" x2="20" y2="40" strokeWidth="1" />
                  </svg>
                </Reveal>
              ))}
            </ul>
          </div>
        </section>

        {/* TEAM */}
        <section id="team" className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="06">Core committee</SectionLabel>
            <h2 className="display-xl mt-8 text-[10vw] sm:text-[7vw] lg:text-[5vw]">
              The people behind the machine.
            </h2>
            <ul className="mt-14 grid border-t border-l border-border sm:grid-cols-2 lg:grid-cols-4">
              {TEAM.map((m, i) => (
                <Reveal
                  as="li"
                  key={m.name}
                  delay={(i % 4) * 60}
                  className="group relative border-r border-b border-border p-6"
                >
                  <div className="relative flex aspect-[4/5] items-center justify-center overflow-hidden bg-secondary">
                    {m.img ? (
                      <img
                        src={m.img}
                        alt={m.name}
                        className="h-full w-full object-cover grayscale transition-all duration-500 group-hover:grayscale-0"
                        loading="lazy"
                      />
                    ) : (
                      <span className="display-xl text-6xl text-steel/40 transition-colors duration-500 group-hover:text-accent/60">
                        {m.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </span>
                    )}
                    <svg
                      viewBox="0 0 100 125"
                      className="pointer-events-none absolute inset-0 h-full w-full stroke-foreground/10"
                      fill="none"
                      aria-hidden
                    >
                      <circle cx="50" cy="62" r="34" strokeWidth="0.5" />
                      <line x1="0" y1="62" x2="100" y2="62" strokeWidth="0.5" />
                      <line x1="50" y1="0" x2="50" y2="125" strokeWidth="0.5" />
                    </svg>
                    <div className="absolute inset-x-0 bottom-0 translate-y-2 bg-background/95 p-4 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                      <p className="tech-label">{m.dept}</p>
                      <a
                        href="#contact"
                        className="tech-label mt-1 inline-block text-accent"
                        aria-label={`LinkedIn profile of ${m.name}`}
                      >
                        LinkedIn &rarr;
                      </a>
                    </div>
                  </div>
                  <h3 className="mt-5 font-display text-lg font-bold uppercase tracking-tight">
                    {m.name}
                  </h3>
                  <p className="tech-label mt-1">{m.role}</p>
                </Reveal>
              ))}
            </ul>
          </div>
        </section>

        {/* GALLERY */}
        <section id="gallery" className="border-t border-border px-5 py-24 md:px-10 md:py-32">
          <div className="mx-auto max-w-[1680px]">
            <SectionLabel index="07">Gallery</SectionLabel>
            <h2 className="display-xl mt-8 text-[10vw] sm:text-[7vw] lg:text-[5vw]">
              Gallery.
            </h2>
            <h3 className="display-xl mt-2 text-[7vw] sm:text-[4.5vw] lg:text-[3vw]">
              Robotics Workshop.
            </h3>
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
              {ROBOTICS_WORKSHOP.map((g, i) => (
                <Reveal key={g.alt} delay={(i % 2) * 70}>
                  <figure className="group border border-border">
                    <img
                      src={g.src}
                      alt={g.alt}
                      width={g.w}
                      height={g.h}
                      loading="lazy"
                      className="w-full object-cover transition-opacity duration-500 group-hover:opacity-85"
                    />
                    <figcaption className="tech-label flex items-center justify-between border-t border-border px-3 py-2">
                      <span>RW / {String(i + 1).padStart(2, "0")}</span>
                      <span className="text-accent">Robotics</span>
                    </figcaption>
                  </figure>
                </Reveal>
              ))}
            </div>

            <h3 className="display-xl mt-20 text-[7vw] sm:text-[4.5vw] lg:text-[3vw]">
              3D Printing Workshop.
            </h3>
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
              {PRINTING_WORKSHOP.map((g, i) => (
                <Reveal key={g.alt} delay={(i % 2) * 70}>
                  <figure className="group border border-border">
                    <img
                      src={g.src}
                      alt={g.alt}
                      width={g.w}
                      height={g.h}
                      loading="lazy"
                      className="w-full object-cover transition-opacity duration-500 group-hover:opacity-85"
                    />
                    <figcaption className="tech-label flex items-center justify-between border-t border-border px-3 py-2">
                      <span>3DP / {String(i + 1).padStart(2, "0")}</span>
                      <span className="text-accent">3D Printing</span>
                    </figcaption>
                  </figure>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <section
          id="contact"
          className="relative overflow-hidden border-t border-border px-5 py-28 md:px-10 md:py-36"
        >
          <div className="pointer-events-none absolute inset-0 blueprint-grid opacity-40" aria-hidden />
          <div className="relative mx-auto max-w-[1680px]">
            <SectionLabel index="08">Join us</SectionLabel>
            <h2 className="display-xl mt-8 text-[12vw] sm:text-[9vw] lg:text-[6.5vw]">
              Ready to build
              <br />
              <span className="text-steel">something?</span>
            </h2>
            <p className="mt-8 max-w-xl text-base leading-relaxed text-steel">
              Join a community of students who design, build, experiment and engineer the future.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <ArrowLink href="mailto:forgeassociation979@gmail.com" variant="solid">
                Join the Association
              </ArrowLink>
              <ArrowLink href="mailto:forgeassociation979@gmail.com" variant="outline">
                Contact Us
              </ArrowLink>
            </div>

            <dl className="mt-20 grid border-t border-border sm:grid-cols-2 lg:grid-cols-4">
              {[
                { k: "Email", v: "forgeassociation979@gmail.com" },
                { k: "Phone (President)", v: "9037484641" },
                { k: "Instagram", v: "@mea.forge" },
                { k: "Department", v: "Mechanical Engineering Block B" },
              ].map((c) => (
                <div key={c.k} className="border-b border-border py-6 pr-8 lg:border-b-0">
                  <dt className="tech-label">{c.k}</dt>
                  <dd className="mt-2 text-sm">{c.v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}

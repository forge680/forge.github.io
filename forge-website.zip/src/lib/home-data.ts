import robotics1 from "@/assets/robotics-1.jpg.asset.json";
import robotics2 from "@/assets/robotics-2.jpg.asset.json";
import robotics3 from "@/assets/robotics-3.jpg.asset.json";
import robotics4 from "@/assets/robotics-4.jpg.asset.json";
import printing1 from "@/assets/printing-1.jpg.asset.json";
import printing2 from "@/assets/printing-2.jpg.asset.json";
import printing3 from "@/assets/printing-3.jpg.asset.json";
import printing4 from "@/assets/printing-4.jpg.asset.json";
import printing5 from "@/assets/printing-5.jpg.asset.json";
import printing6 from "@/assets/printing-6.jpg.asset.json";
import principalThajbi from "@/assets/principal-thajbi.png.asset.json";
import hodJinto from "@/assets/hod-jinto.webp.asset.json";
import staff1 from "@/assets/staff-1.png.asset.json";
import staff2 from "@/assets/staf_331.jpg.asset.json";
import staff3 from "@/assets/staf_353.jpg.asset.json";
import staff4 from "@/assets/staf_333.jpg.asset.json";
import staff5 from "@/assets/staf_335.jpg.asset.json";
import staff6 from "@/assets/staf_336.jpg.asset.json";
import staff7 from "@/assets/staf_337.jpg.asset.json";
import staff8 from "@/assets/staf_358.jpg.asset.json";
import projFormula from "@/assets/proj-formula.jpg";
import projRobot from "@/assets/proj-robot.jpg";
import projCnc from "@/assets/proj-cnc.jpg";
import projSolar from "@/assets/proj-solar.jpg";
import teamB from "@/assets/team-b.jpg.asset.json";
import sidharth from "@/assets/sidharth-president.jpg.asset.json";
import ananya from "@/assets/ananya-vice-president.jpg.asset.json";
import dheeraj from "@/assets/dheeraj-technical-event-lead.jpg.asset.json";
import abhinanandha from "@/assets/abhinanandha-treasurer.png.asset.json";

export const DOMAINS = [
  { n: "01", t: "CAD & Design", d: "Parametric modelling, GD&T, assemblies and design for manufacture." },
  { n: "02", t: "Manufacturing", d: "Machining, casting, welding and process planning on real hardware." },
  { n: "03", t: "Automotive", d: "Powertrain, chassis, suspension and vehicle dynamics." },
  { n: "04", t: "Robotics", d: "Kinematics, actuators, control and mechatronic integration." },
  { n: "05", t: "Thermal Engineering", d: "Heat transfer, IC engines, HVAC and energy systems." },
  { n: "06", t: "Mechatronics", d: "Sensors, embedded control and automated motion systems." },
];

export const PROJECTS = [
  {
    img: projFormula,
    name: "Formula Student FS-04",
    desc: "A tubular space-frame race car built end-to-end by a 22-student crew.",
    year: "2026",
    cat: "Automotive",
    tags: ["Chassis", "FEA", "Powertrain"],
  },
  {
    img: projRobot,
    name: "6-Axis Robotic Arm",
    desc: "Harmonic-drive manipulator with inverse-kinematic trajectory control.",
    year: "2025",
    cat: "Robotics",
    tags: ["Kinematics", "3D Print", "Control"],
  },
  {
    img: projCnc,
    name: "Desktop CNC Mill",
    desc: "Rigid three-axis mill machining aluminium to ±0.05 mm tolerance.",
    year: "2025",
    cat: "Manufacturing",
    tags: ["CNC", "Ballscrew", "G-Code"],
  },
  {
    img: projSolar,
    name: "Solar Utility Vehicle",
    desc: "Lightweight solar drivetrain for low-speed campus logistics.",
    year: "2024",
    cat: "Energy",
    tags: ["Drivetrain", "Composites", "Telemetry"],
  },
];

export const EVENTS = [
  { d: "18", m: "Sep", name: "Inauguration Day", loc: "Main Seminar Hall", cat: "Ceremony" },
];

export const WORKSHOPS = [
  "SolidWorks",
  "AutoCAD",
  "CNC Machining",
  "3D Printing",
  "Welding",
  "Manufacturing",
  "Robotics",
];

export const TEAM = [
  { name: "SIDHARTH E", role: "President", dept: "Mechanical, Third Year", img: sidharth.url },
  { name: "ANANYA RAJESH", role: "Vice President", dept: "Mechanical, Final Year", img: ananya.url },
  { name: "DHEERAJ RAJEEV", role: "Technical Event Lead", dept: "Mechanical, Final Year", img: dheeraj.url },
  { name: "ABHINANANDHA SJ", role: "Treasurer", dept: "Mechanical, Second Year", img: abhinanandha.url },
  { name: "AVINESH PS", role: "Design Head", dept: "Mechanical, Third Year", img: teamB.url },
];

export const ROBOTICS_WORKSHOP = [
  { src: robotics1.url, alt: "Students filling the auditorium at the robotics workshop", w: 1280, h: 578 },
  { src: robotics2.url, alt: "Speaker addressing students during the robotics workshop", w: 1280, h: 578 },
  { src: robotics3.url, alt: "Introduction to robotics presentation on screen", w: 1280, h: 578 },
  { src: robotics4.url, alt: "Interactive session with students at the robotics workshop", w: 1280, h: 578 },
];

export const PRINTING_WORKSHOP = [
  { src: printing1.url, alt: "Student speaking during the 3D printing workshop", w: 1600, h: 730 },
  { src: printing2.url, alt: "Classroom session on additive vs subtractive manufacturing", w: 1600, h: 730 },
  { src: printing3.url, alt: "Students attending the additive manufacturing session", w: 1600, h: 730 },
  { src: printing4.url, alt: "Presentation on 3D printing to a full classroom", w: 1600, h: 730 },
  { src: printing5.url, alt: "Speaker introducing the Security and 3D Printing Workshop", w: 1600, h: 730 },
  { src: printing6.url, alt: "Wide view of the 3D printing workshop audience", w: 1600, h: 730 },
];

export const PRINCIPAL = [
  {
    name: "Ms. Thajbi P. M.",
    title: "Principal",
    qualification: "M.Tech.",
    img: principalThajbi.url,
  },
];

export const HOD = [
  {
    name: "Jinto Francis P B",
    title: "Head of Department",
    qualification: "M.Tech",
    img: hodJinto.url,
  },
];

export const STAFF = [
  { name: "T. S. Saloop", title: "Lecturer", qualification: "M.Tech. in Energy Management", email: "forgeassociation979@gmail.com", img: staff1.url },
  { name: "Jijo Prasad J R", title: "Lecturer", qualification: "Mechanical Engineering", img: staff2.url },
  { name: "Kamal D", title: "Lecturer", qualification: "Mechanical Engineering", img: staff3.url },
  { name: "Rijish K S", title: "Demonstrator", qualification: "Mechanical Engineering", img: staff4.url },
  { name: "Rajesh V U", title: "Demonstrator", qualification: "Mechanical Engineering", img: staff5.url },
  { name: "Bijoy K M", title: "Trade Instructor", qualification: "Mechanical Engineering", img: staff6.url },
  { name: "Kannan K K", title: "Trade Instructor", qualification: "Mechanical Engineering", img: staff7.url },
  { name: "Jayadev K V", title: "Tradesman", qualification: "Mechanical Engineering", img: staff8.url },
  { name: "Staff Member 09", title: "Lecturer", qualification: "Mechanical Engineering" },
  { name: "Staff Member 10", title: "Lecturer", qualification: "Mechanical Engineering" },
];

